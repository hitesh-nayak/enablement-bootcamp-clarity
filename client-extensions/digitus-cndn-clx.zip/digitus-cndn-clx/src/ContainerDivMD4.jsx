import React from "react";

const ContainerDivMD4 = ({ children }) => {
    return (
        <React.Fragment>

            <div className="col-md-4">

                {children}

            </div>

        </React.Fragment>
    )
}

export default ContainerDivMD4;