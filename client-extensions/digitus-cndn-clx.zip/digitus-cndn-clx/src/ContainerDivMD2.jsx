import React from "react";

const ContainerDivMD2 = ({ children }) => {
    return (
        <React.Fragment>

            <div className="col-md-2">

                {children}

            </div>

        </React.Fragment>
    )
}

export default ContainerDivMD2;


