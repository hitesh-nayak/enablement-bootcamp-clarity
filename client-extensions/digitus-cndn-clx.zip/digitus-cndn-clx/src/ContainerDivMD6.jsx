import React from "react";

const ContainerDivMD6 = ({ children }) => {
    return (
        <React.Fragment>

                <div className="col-md-6">

                    {children}

                </div>

        </React.Fragment>
    )
}

export default ContainerDivMD6;