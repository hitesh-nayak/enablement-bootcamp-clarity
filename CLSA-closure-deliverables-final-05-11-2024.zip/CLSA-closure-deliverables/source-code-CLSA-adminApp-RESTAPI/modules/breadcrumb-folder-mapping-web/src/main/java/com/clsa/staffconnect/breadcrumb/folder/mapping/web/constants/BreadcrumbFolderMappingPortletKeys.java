package com.clsa.staffconnect.breadcrumb.folder.mapping.web.constants;

/**
 * @author me
 */
public class BreadcrumbFolderMappingPortletKeys {

	public static final String BREADCRUMBFOLDERMAPPING =
		"com_clsa_staffconnect_breadcrumb_folder_mapping_web_BreadcrumbFolderMappingPortlet";

}