package com.clsa.staffconnect.breadcrumb.folder.mapping.web.constants;

/**
 * @author me
 */
public class BreadcrumbFolderMappingPanelCategoryKeys {

	public static final String CONTROL_PANEL_CATEGORY = "BreadcrumbFolderMapping";

}