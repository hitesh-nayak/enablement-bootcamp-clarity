package com.clsa.staffconnect.breadcrumb.folder.mapping.web.internal.display.context;

import com.liferay.portal.kernel.display.context.helper.BaseRequestHelper;

import javax.servlet.http.HttpServletRequest;

/**
 * @author Krishna Rajappa
 */
public class BCFMappingRequestHelper extends BaseRequestHelper {

	public BCFMappingRequestHelper(HttpServletRequest httpServletRequest) {
		super(httpServletRequest);
	}

}